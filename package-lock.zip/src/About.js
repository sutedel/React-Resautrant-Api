import { Card } from "react-bootstrap";

export default function About() {

    return (
        <>
        <Card>
        <Card.Img style={{ width: '18rem' }} variant="top" src="https://www.smartclouds.co/Themes/SmartClouds/Content/images/info/info-img-1.png"/>

            <Card.Body>
                <Card.Title>About</Card.Title>
                <Card.Text>
                My name is Ahmad Jafari, and I am a Software Engineer. In terms of education, I have a Bachelor of Computer Software Engineering from Iran, and I am trained in Asp.Net, SQL, Entity Framework, MVC and SEO.
I am experienced in Programming languages: C#.NET, C++, JavaScript, T-SQL and LINQ. MICROSOFT TECHNOLOGY: MS OFFICE, IIS, Visual Studio, Windows Server and  WEB TECHNOLOGIES: HTML, CSS, Java Script, XML, JQuery. 
I am passionate about  working on Machine Learning(Machine Learning) to improve trade marketing.
The best way to contact me is to email me at mjafari22@myseneca.ca.



                </Card.Text>
            </Card.Body>
        </Card>
     
        </>
        );
}